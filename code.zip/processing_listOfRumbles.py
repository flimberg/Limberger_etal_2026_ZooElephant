import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
from scipy.stats import norm
import matplotlib.gridspec as gridspec
import matplotlib.dates as mdates
from scipy.signal import savgol_filter
import time
start = time.time()

# Set global font sizes
plt.rcParams['axes.labelsize'] = 14   # Font size for x and y labels
plt.rcParams['xtick.labelsize'] = 12  # Font size for x-axis tick labels
plt.rcParams['ytick.labelsize'] = 12  # Font size for y-axis tick labels
plt.rcParams['legend.fontsize'] = 12  # Font size for legend


# Define a function to load and process the CSV files from a given directory
def load_data_from_csv(directory):
    data = []
    for file in os.listdir(directory):
        if file.endswith('.csv'):
            df = pd.read_csv(os.path.join(directory, file))
            data.append(df)
    
    # Combine all the data from different files into one DataFrame
    combined_data = pd.concat(data, ignore_index=True)
    combined_data['Time'] = pd.to_datetime(combined_data['Time'])  # Convert Time column to datetime
    combined_data['Hour'] = combined_data['Time'].dt.hour  # Extract the hour of the event

    return combined_data


def check_consecutive_events(df, time_threshold=15):
    """
    Check for consecutive events occurring within a specified time threshold,
    and plot the frequency distribution for each event type.

    Parameters:
    df (pd.DataFrame): DataFrame containing event data with a 'Time' column.
    time_threshold (int): Time threshold in seconds to consider events consecutive.

    Returns:
    dict: A dictionary containing counts of single, double, triple, quadruple, and five or more consecutive events,
          and the hour of the first event in each category.
    """
    counts = {
        'single': 0,
        'double': 0,
        'triple': 0,
        'quadruple': 0,
        'five_or_more': 0
    }
    
    # Lists to store frequencies, durations, and hours of the first event
    freqs1, freqs2, freqs3, freqs4 = [], [], [], []
    dur1, dur2, dur3, dur4 = [], [], [], []
    first_event_hours1, first_event_hours2, first_event_hours3, first_event_hours4 = [], [], [], []
    
    df_sorted = df.sort_values(by='Time')

    for i in range(len(df_sorted)):
        current_event_time = df_sorted['Time'].iloc[i]
        next_event_time = df_sorted['Time'].iloc[i + 1] if i + 1 < len(df_sorted) else None
        prev_event_time = df_sorted['Time'].iloc[i - 1] if i - 1 >= 0 else None
        
        has_event_before = (prev_event_time is not None and (current_event_time - prev_event_time).total_seconds() <= time_threshold)
        has_event_after = (next_event_time is not None and (next_event_time - current_event_time).total_seconds() <= time_threshold)
        
        if has_event_after and not has_event_before:
            # Check for a potential multi-event scenario
            count = 1  # Start with the current event
            
            while i + count < len(df_sorted) and (df_sorted['Time'].iloc[i + count] - df_sorted['Time'].iloc[i + count - 1]).total_seconds() <= time_threshold:
                count += 1
            
            if count == 1:
                counts['single'] += 1
                first_event_hours1.append(current_event_time.hour)
            elif count == 2:
                counts['double'] += 1
                freqs1.append(df_sorted['Frequency (Hz)'].iloc[i])
                freqs2.append(df_sorted['Frequency (Hz)'].iloc[i + 1])
                dur1.append(df_sorted['Duration (s)'].iloc[i])
                dur2.append(df_sorted['Duration (s)'].iloc[i + 1])
                first_event_hours2.append(current_event_time.hour)
            elif count == 3:
                counts['triple'] += 1
                freqs1.append(df_sorted['Frequency (Hz)'].iloc[i])
                freqs2.append(df_sorted['Frequency (Hz)'].iloc[i + 1])
                freqs3.append(df_sorted['Frequency (Hz)'].iloc[i + 2])
                dur1.append(df_sorted['Duration (s)'].iloc[i])
                dur2.append(df_sorted['Duration (s)'].iloc[i + 1])
                dur3.append(df_sorted['Duration (s)'].iloc[i + 2])
                first_event_hours3.append(current_event_time.hour)
            elif count == 4:
                counts['quadruple'] += 1
                freqs1.append(df_sorted['Frequency (Hz)'].iloc[i])
                freqs2.append(df_sorted['Frequency (Hz)'].iloc[i + 1])
                freqs3.append(df_sorted['Frequency (Hz)'].iloc[i + 2])
                freqs4.append(df_sorted['Frequency (Hz)'].iloc[i + 3])
                dur1.append(df_sorted['Duration (s)'].iloc[i])
                dur2.append(df_sorted['Duration (s)'].iloc[i + 1])
                dur3.append(df_sorted['Duration (s)'].iloc[i + 2])
                dur4.append(df_sorted['Duration (s)'].iloc[i + 3])
                first_event_hours4.append(current_event_time.hour)
            else:
                counts['five_or_more'] += 1

        elif not has_event_before and not has_event_after:
            counts['single'] += 1
            first_event_hours1.append(current_event_time.hour)

    return counts, freqs1, freqs2, freqs3, freqs4, dur1, dur2, dur3, dur4, first_event_hours1, first_event_hours2, first_event_hours3, first_event_hours4




def average_daily_profile(df):
    """
    Averages the amplitude data across the same 10-minute interval of different days,
    removing high-value outliers.

    Parameters:
    df (pd.DataFrame): DataFrame containing 'time' and 'amplitude' columns.

    Returns:
    pd.DataFrame: DataFrame with average amplitude for each 10-minute interval across days.
    """
    # Ensure 'time' is a datetime object
    df['time'] = pd.to_datetime(df['time'])

    # Round down to the nearest 10 minutes to create 10-minute intervals
    df['time_10min'] = df['time'].dt.floor('10T').dt.strftime('%H:%M')

    # Identify and remove high-value outliers
    Q1 = df['amplitude'].quantile(0.25)
    Q3 = df['amplitude'].quantile(0.75)
    IQR = Q3 - Q1
    upper_bound = Q3 + 1.5 * IQR

    # Filter out high-value outliers
    filtered_df = df[df['amplitude'] <= upper_bound]

    # Group by 10-minute interval (across all days) and calculate the mean amplitude
    daily_avg = filtered_df.groupby('time_10min')['amplitude'].mean().reset_index()

    # Convert 'time_10min' back to time format for consistent output
    daily_avg['time'] = pd.to_datetime(daily_avg['time_10min'], format='%H:%M').dt.time

    return daily_avg[['time', 'amplitude']]
    
def find_matching_events(seismic_df, infra_df):
    """
    Find seismic events that occur within ±1.5 seconds and ±5 Hz of infrasound events,
    and plot their frequencies in a freq-freq plot, along with their durations in a separate subplot.

    Parameters:
    seismic_df (pd.DataFrame): DataFrame containing seismic event data with 'Time', 'Frequency (Hz)', and 'Duration (s)' columns.
    infra_df (pd.DataFrame): DataFrame containing infrasound event data with 'Time', 'Frequency (Hz)', and 'Duration (s)' columns.
    """
    # Ensure 'Time' columns are datetime objects
    seismic_df['Time'] = pd.to_datetime(seismic_df['Time'])
    infra_df['Time'] = pd.to_datetime(infra_df['Time'])

    # Initialize lists to hold matching frequencies and durations
    seismic_frequencies = []
    infra_frequencies = []
    seismic_durations = []
    infra_durations = []

    # Iterate over each infrasound event to find matching seismic events within ±1.5 seconds and ±5 Hz
    for infra_time, infra_frequency, infra_duration in zip(infra_df['Time'], infra_df['Frequency (Hz)'], infra_df['Duration (s)']):
        # Define the time and frequency window for matching
        time_window = (seismic_df['Time'] >= infra_time - pd.Timedelta(seconds=1.5)) & \
                      (seismic_df['Time'] <= infra_time + pd.Timedelta(seconds=1.5))
        frequency_window = (seismic_df['Frequency (Hz)'] >= infra_frequency - 5) & \
                           (seismic_df['Frequency (Hz)'] <= infra_frequency + 5)

        # Find seismic events that match both time and frequency windows
        matched_seismic_events = seismic_df[time_window & frequency_window]

        # Store matched frequencies and durations if any
        if not matched_seismic_events.empty:
            for _, matched_event in matched_seismic_events.iterrows():
                seismic_frequencies.append(matched_event['Frequency (Hz)'])
                infra_frequencies.append(infra_frequency)
                seismic_durations.append(matched_event['Duration (s)'])
                infra_durations.append(infra_duration)

    # Convert to DataFrame for plotting
    matching_events_df = pd.DataFrame({
        'seismic_frequency': seismic_frequencies,
        'infra_frequency': infra_frequencies,
        'seismic_duration': seismic_durations,
        'infra_duration': infra_durations
    })

    # Plotting
    if not matching_events_df.empty:
        fig, axs = plt.subplots(1, 2, figsize=(14, 6))

        # Frequency vs. Frequency plot
        axs[0].scatter(matching_events_df['seismic_frequency'], matching_events_df['infra_frequency'], alpha=0.7, color='navy')
        axs[0].plot([10, 70], [10, 70], color='r', linestyle='dashed')
        axs[0].set_xlabel('Seismic Frequency (Hz)')
        axs[0].set_ylabel('Infrasound Frequency (Hz)')
        axs[0].grid(True)

        # Duration vs. Duration plot
        axs[1].scatter(matching_events_df['seismic_duration'], matching_events_df['infra_duration'], alpha=0.7, color='green')
        axs[1].plot([0, max(max(matching_events_df['seismic_duration']), max(matching_events_df['infra_duration']))], 
                    [0, max(max(matching_events_df['seismic_duration']), max(matching_events_df['infra_duration']))], 
                    color='r', linestyle='dashed')
        axs[1].set_xlabel('Seismic Duration (s)')
        axs[1].set_ylabel('Infrasound Duration (s)')
        axs[1].grid(True)

        plt.tight_layout()
        plt.show()
    else:
        print("No matching events found within the specified time and frequency frame.")
        
        
# Function to create scatter and histogram plots
def create_plots(df):
    # Prepare data
    infrasound = df[df['Label'] == 'infrasound']
    seismic = df[df['Label'] == 'seismic']
    
    ###############################
    # Scatter plot of frequency vs. duration
    infrasound_count = len(infrasound)
    seismic_count = len(seismic)

    # Define figure and grid spec
    fig = plt.figure(figsize=(10, 8))
    gs = gridspec.GridSpec(4, 4, hspace=0.1, wspace=0.1)

    # Scatter plot: frequency vs duration
    ax_scatter = fig.add_subplot(gs[1:4, 0:3])
    ax_scatter.grid(True, alpha=0.3)
    ax_scatter.scatter(infrasound['Duration (s)'], infrasound['Frequency (Hz)'], color='orange', 
                       label=f'Infrasound ({infrasound_count})', alpha=0.7,s=5)
    ax_scatter.scatter(seismic['Duration (s)'], seismic['Frequency (Hz)'], color='navy', 
                       label=f'Seismic ({seismic_count})', alpha=0.7,s=5)
    ax_scatter.set_xlabel('Duration (s)')
    ax_scatter.set_ylabel('Frequency (Hz)')
    ax_scatter.legend()

    # Frequency histogram (attached to the y-axis)
    ax_hist_freq = fig.add_subplot(gs[1:4, 3], sharey=ax_scatter)
    ax_hist_freq.hist(infrasound['Frequency (Hz)'], color='orange', alpha=0.7, bins=30, orientation='horizontal',
                      edgecolor='black', linewidth=1.2)
    ax_hist_freq.hist(seismic['Frequency (Hz)'], color='navy', alpha=0.7, bins=30, orientation='horizontal',
                      edgecolor='black', linewidth=1.2)
    ax_hist_freq.set_xlabel('Count')

    # Duration histogram (attached to the x-axis)
    ax_hist_dur = fig.add_subplot(gs[0, 0:3], sharex=ax_scatter)
    ax_hist_dur.hist(infrasound['Duration (s)'], color='orange', alpha=0.7, bins=30, edgecolor='black', linewidth=1.2)
    ax_hist_dur.hist(seismic['Duration (s)'], color='navy', alpha=0.7, bins=30, edgecolor='black', linewidth=1.2)
    ax_hist_dur.set_ylabel('Count')

    # Hide tick labels on the shared axes to make the plot clean
    plt.setp(ax_hist_dur.get_xticklabels(), visible=False)
    plt.setp(ax_hist_freq.get_yticklabels(), visible=False)

    plt.show()

    
    
    find_matching_events(seismic,infrasound)
    
    
    
    ##################################################
    # Frequency vs Time scatter plot
    # Load results from CSV
    df_results = pd.read_csv("./secondaryMaterial/mean_amplitudes_seismic_mean_5min_chunks.csv")
    
    df_results['time'] = pd.to_datetime(df_results['time'])
    df_results['amplitude'] = df_results['amplitude'] / 25000

    # Load infrasound results
    #df_results_infra = pd.read_csv("mean_amplitudes_infra.csv")
    df_results_infra = pd.read_csv("./secondaryMaterial/mean_amplitudes_infrasound_mean_5min_chunks.csv")
    
    df_results_infra['time'] = pd.to_datetime(df_results_infra['time'])
    df_results_infra['amplitude'] = df_results_infra['amplitude'] / 1500000

    infrasound_count = len(infrasound)
    seismic_count = len(seismic)

    # Combine infrasound and seismic events for histogram counts
    all_events = pd.concat([infrasound['Time'], seismic['Time']])
    events_per_day = all_events.dt.date.value_counts().sort_index()   

            
            
            
    filtered_df_infra = df[(df['Label'] == 'infrasound') & 
                 (df['Frequency (Hz)'] >= 25) & 
                 (df['Frequency (Hz)'] <= 45)]    
    filtered_df_seismic = df[(df['Label'] == 'seismic') & 
                 (df['Frequency (Hz)'] >= 25) & 
                 (df['Frequency (Hz)'] <= 45)]     
    
    hourly_counts_infra = filtered_df_infra.groupby(pd.Grouper(key='Time', freq='2H')).size()
    hourly_counts_seismic = filtered_df_seismic.groupby(pd.Grouper(key='Time', freq='2H')).size()

    # Create the figure and subplots
    fig, (ax_hist, ax_scatter, ax_noise) = plt.subplots(3, 1, figsize=(12, 8), gridspec_kw={'height_ratios': [1, 3, 1]}, sharex=True)

    # Plot the histogram of event counts per day with bars starting at the tick
    #ax_hist.bar(events_per_day.index, events_per_day.values, color='gray', alpha=0.7, align='edge', width=1.0, edgecolor='black')
    ax_hist.plot(hourly_counts_infra.index, hourly_counts_infra.values, linestyle='-', color='orange', label='Infrasound')
    ax_hist.plot(hourly_counts_seismic.index, hourly_counts_seismic.values, linestyle='-', color='navy', label='Seismic')
    ax_hist.set_ylabel('Rumble Count')
    ax_hist.grid(True, alpha=0.3)
    ax_hist.legend(loc='upper left')
    #ax_hist.set_yticks([50, 100, 150, 200, 250])
    ax_hist.set_yticks([10, 20, 30])
    # Frequency vs Time scatter plot


    ax_scatter.scatter(infrasound['Time'], infrasound['Frequency (Hz)'], color='orange', alpha=0.7, s=6 , label=f'Infrasound')
    ax_scatter.scatter(seismic['Time'], seismic['Frequency (Hz)'], color='navy', alpha=0.7, s=6, label=f'Seismic')

    ax_scatter.set_ylim(10, 60)
 ########################################
  ########################################
    start_time = pd.Timestamp('2024-08-02')
    end_time = pd.Timestamp('2024-08-31') + pd.Timedelta(days=1)  # Extend by one day
    ax_scatter.set_xlim(start_time, end_time)
 ########################################
  ########################################    
    ax_scatter.set_ylabel('Frequency (Hz)')
    ax_scatter.grid(True, alpha=0.3)
    #ax_scatter.legend(loc='upper left')
    
    # Add shading for each day from 07:00 to 17:00
    current_date = start_time.floor('D')
    while current_date <= end_time:
        ax_hist.axvspan(current_date + pd.Timedelta(hours=7), 
                           current_date + pd.Timedelta(hours=17), 
                           color='k', alpha=0.1)
        ax_scatter.axvspan(current_date + pd.Timedelta(hours=7), 
                           current_date + pd.Timedelta(hours=17), 
                           color='k', alpha=0.1)
        ax_noise.axvspan(current_date + pd.Timedelta(hours=7), 
                         current_date + pd.Timedelta(hours=17), 
                         color='k', alpha=0.1)
        current_date += pd.Timedelta(days=1)
    
    #ax_noise.plot(df_results_infra['time'], df_results_infra['amplitude'], linestyle='-', color='orange', alpha=0.5, label='Infras. mean noise')
    ax_noise.plot(df_results['time'], df_results['amplitude']/7, linestyle='-', color='navy')
    ax_noise.set_ylim(0,1.1)
    ax_noise.set_xlabel('Time')
    ax_noise.set_ylabel('Seis. noise')
    #ax_noise.legend(loc='upper left')
    # Adjust the x-axis date format
    # Add x-ticks for every day
    #ax_noise.xaxis.set_major_locator(mdates.DayLocator())  # Set daily ticks
    
    # Set a locator that changes based on the zoom level
    ax_noise.xaxis.set_major_locator(mdates.AutoDateLocator())  # Automatically choose the best locator
    ax_noise.xaxis.set_major_formatter(mdates.ConciseDateFormatter(mdates.AutoDateLocator()))  # Dynamic formatting
   
    plt.xticks(rotation=45)

    # Display the plot
    plt.tight_layout()
    plt.show()
    
    
    ##############################################
    # Histogram of event appearance over the day (by hour) for specified frequency ranges
    infrasound_counts_25_45 = infrasound[(infrasound['Frequency (Hz)'] >= 25) & (infrasound['Frequency (Hz)'] <= 45)]['Hour'].value_counts().sort_index()
    seismic_counts_25_45 = seismic[(seismic['Frequency (Hz)'] >= 25) & (seismic['Frequency (Hz)'] <= 45)]['Hour'].value_counts().sort_index()
    
    print(infrasound[(infrasound['Frequency (Hz)'] >= 25) & (infrasound['Frequency (Hz)'] <= 45)]['Hour'])


    infrasound_counts_1_25 = infrasound[(infrasound['Frequency (Hz)'] >= 1) & (infrasound['Frequency (Hz)'] < 25)]['Hour'].value_counts().sort_index()
    seismic_counts_1_25 = seismic[(seismic['Frequency (Hz)'] >= 1) & (seismic['Frequency (Hz)'] < 25)]['Hour'].value_counts().sort_index()

    hours = np.arange(24)
    infrasound_counts_25_45 = infrasound_counts_25_45.reindex(hours, fill_value=0)
    seismic_counts_25_45 = seismic_counts_25_45.reindex(hours, fill_value=0)

    infrasound_counts_1_25 = infrasound_counts_1_25.reindex(hours, fill_value=0)
    seismic_counts_1_25 = seismic_counts_1_25.reindex(hours, fill_value=0)

    bar_width = 0.4  # Increased bar width for better visibility
    x_infrasound_25_45 = hours - bar_width / 2
    x_seismic_25_45 = hours + bar_width / 2
    x_infrasound_1_25 = hours - bar_width / 2
    x_seismic_1_25 = hours + bar_width / 2

    print(infrasound_counts_25_45)
    
    
    df_day_avg = average_daily_profile(df_results)
    df_day_avg_infra = average_daily_profile(df_results_infra)
    
    
    # Load the CSV data for VISITORS
    # Assuming the CSV file is named 'data.csv' and formatted as described
    df_visitors = pd.read_csv('./secondaryMaterial/visitors.csv', delimiter=';', header=None)
    df_visitors.columns = ['hour', 'amplitude']

    # Ensure the 'hour' column is numeric and the 'amplitude' column is converted to float
    df_visitors['hour'] = pd.to_numeric(df_visitors['hour'].str.replace(',', '.'))-2
    df_visitors['amplitude'] = pd.to_numeric(df_visitors['amplitude'].str.replace(',', '.'))
    
    # Create the bar plot for both frequency ranges as subplots
    plt.figure(figsize=(12, 8))

    # Subplot for 25 Hz to 45 Hz
    plt.subplot(2, 1, 1)
    plt.grid(True,alpha=0.3)

    plt.bar(x_infrasound_25_45, infrasound_counts_25_45, width=bar_width, color='orange', 
            label=f'Infrasound ({infrasound_counts_25_45.sum()})')
    plt.bar(x_seismic_25_45, seismic_counts_25_45, width=bar_width, color='navy', 
            label=f'Seismic ({seismic_counts_25_45.sum()})')
    
    # plot as lines        
    #plt.plot(hours,infrasound_counts_25_45, '.-', color='orange', label=f'Infrasound({infrasound_counts_1_25.sum()})')
    #plt.plot(hours, seismic_counts_25_45, '.-', color='navy', label=f'Seismic({infrasound_counts_1_25.sum()})')
    
    plt.axvline(x=7, color='red', linestyle='--', label='Opening / Closing Zoo')
    plt.axvline(x=17, color='red', linestyle='--')
    
    plt.plot(np.arange(0, 24, 1/6), df_day_avg['amplitude']/np.min(df_day_avg['amplitude'])*8, linestyle='--', color='navy',  label='Daily Avg. Seism. Noise')
    plt.plot(df_visitors['hour'],df_visitors['amplitude']/np.max(df_visitors['amplitude'])*40,color='k',  label='Visitors')
    
    plt.title('Mean hourly activity - 25 Hz to 45 Hz')
    #plt.xlabel('Hour of the Day')
    plt.ylabel('Count')
    plt.xticks(hours)
    plt.legend(loc='upper left')   
    
    # Subplot for 1 Hz to 25 Hz
    plt.subplot(2, 1, 2)
    plt.grid(True,alpha=0.3)
    
    plt.plot(np.arange(0, 24, 1/6), df_day_avg['amplitude']/np.min(df_day_avg['amplitude'])*8, linestyle='--', color='navy',  label='Daily Avg. Seism. Noise')
    plt.plot(df_visitors['hour'],df_visitors['amplitude']/np.max(df_visitors['amplitude'])*40,color='k',  label='Visitors')
    
    #plt.plot(np.arange(0, 24, 1), df_day_avg_infra['amplitude']/np.min(df_day_avg_infra['amplitude'])*4, linestyle='-', color='orange', alpha=0.5, label='Daily Avg. Infra. Noise')
    plt.bar(x_infrasound_1_25, infrasound_counts_1_25, width=bar_width, color='orange', 
            label=f'Infrasound 1-25 Hz ({infrasound_counts_1_25.sum()})')
    plt.bar(x_seismic_1_25, seismic_counts_1_25, width=bar_width, color='navy', 
            label=f'Seismic 1-25 Hz ({seismic_counts_1_25.sum()})')
            

    
    plt.axvline(x=7, color='red', linestyle='--', label='Opening / Closing Zoo')
    plt.axvline(x=17, color='red', linestyle='--')
    
    plt.title('Mean hourly activity - 1 Hz to 25 Hz')
    plt.xlabel('Hour of the Day')
    plt.ylabel('Count')
    plt.xticks(hours)
    #plt.legend(loc='upper left')
    
    plt.tight_layout()
    plt.show()    


######################################################################    
    
    # Filter events between 25 Hz and 45 Hz
    filtered_events = infrasound[(infrasound['Frequency (Hz)'] >= 25) & (infrasound['Frequency (Hz)'] <= 45)]

    # Sort the filtered events by time
    sorted_events = filtered_events.sort_values(by='Time')

    # Extract the 'Time' column and calculate time differences in seconds
    event_times = sorted_events['Time']
    time_differences = event_times.diff().dt.total_seconds().dropna()

    # Count the number of occurrences for each condition
    count_less_than_equal_5s = (time_differences <= 5).sum()
    count_greater_5_and_less_equal_10s = ((time_differences > 5) & (time_differences <= 10)).sum()
    count_greater_10_and_less_equal_30s = ((time_differences > 10) & (time_differences <= 30)).sum()
    count_greater_30_and_less_equal_60s = ((time_differences > 30) & (time_differences <= 60)).sum()
    count_greater_60_and_less_equal_120s = ((time_differences > 60) & (time_differences <= 120)).sum()
    count_greater_120s = (time_differences > 120).sum()

    # Bar plot data
    categories = [
        '<= 5s',
        '5 - 10s',
        '10 - 30s',
        '30 - 60s',
        '60 - 120s',
        '> 120s'
    ]
    counts = [
        count_less_than_equal_5s,
        count_greater_5_and_less_equal_10s,
        count_greater_10_and_less_equal_30s,
        count_greater_30_and_less_equal_60s,
        count_greater_60_and_less_equal_120s,
        count_greater_120s
    ]

    # Plot the bar chart
    plt.figure(figsize=(12, 6))
    plt.bar(categories, counts, color='black', edgecolor='black')
    plt.title('Counts of Time Differences Between Rumbles')
    plt.ylabel('Count')
    plt.grid(True, axis='y', alpha=0.3)
    plt.xticks(rotation=15)
    plt.show()

    
    def load_and_plot_histogram(file_path):
        # Load the CSV file
        data = pd.read_csv(file_path)
        
        # Convert the 'Timestamp' column to datetime if it's not already
        data['Timestamp'] = pd.to_datetime(data['Timestamp'])
        
        # Filter out data between 7:00 and 17:00
        #data = data[~((data['Timestamp'].dt.hour >= 7) & (data['Timestamp'].dt.hour < 17))]

        # Group by Timestamp and aggregate labels into lists
        grouped_data = data.groupby('Timestamp')['Label'].agg(lambda x: list(set(x))).reset_index()

        # Define the combinations to check, including 'none'
        combinations = [
            'yes',
            'no',
            'not sure'
        ]

        # Initialize counts and frequency lists
        combination_counts = {combo: 0 for combo in combinations}
        frequency_data = {combo: [] for combo in combinations}

        # Check each row's labels and count combinations
        for index, row in grouped_data.iterrows():
            labels = row['Label']
            frequencies = data[data['Timestamp'] == row['Timestamp']]['Frequency (Hz)'].tolist()

            # Count individual labels and collect frequencies
            if 'yes' in labels:
                combination_counts['yes'] += 1
                frequency_data['yes'].extend(frequencies)
            if 'yes multiple rumbles' in labels:
               # combination_counts['yes and multiple rumbles'] += 1
               # frequency_data['yes and multiple rumbles'].extend(frequencies)
                combination_counts['yes'] += 1
                frequency_data['yes'].extend(frequencies)
            if 'none' in labels:
                combination_counts['no'] += 1
                frequency_data['no'].extend(frequencies)
            if 'not sure' in labels:
                combination_counts['not sure'] += 1
                frequency_data['not sure'].extend(frequencies)
          
        # Prepare data for histogram plotting
        label_counts = list(combination_counts.values())
        labels = list(combination_counts.keys())

        # Plot histogram for label combinations
        plt.figure(figsize=(6, 5))
        plt.bar(labels, label_counts/np.max(label_counts), color='black', edgecolor='black')
        plt.xlabel('Label Combinations')
        plt.ylabel('Counts')
        plt.title('Histogram of Label Combinations')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()
     

    # Example usage
    load_and_plot_histogram('rumble_and_trampling.csv')   
    
    
    
    
# Main function
def main():
    directory = './'  # Update this path to the location of your CSV files
    print('Load data...')
    df = load_data_from_csv(directory)

    # Find marked lower frequency and higher frequency events
    print('Make plots...')
    # Create scatter plots and histograms
    create_plots(df)

if __name__ == '__main__':
    main()
