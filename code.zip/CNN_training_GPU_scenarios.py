# =====================================================
# CNN Cross-Domain Evaluation Script 
# =====================================================

import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset, ConcatDataset, Subset
from torchvision import transforms
from PIL import Image
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix

# =====================================================
# Global parameters 
# =====================================================

LEARNING_RATE = 0.0005
BATCH_SIZE = 8
EPOCHS = 30
FINAL_DROPOUT = 0.4
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("Using device:", DEVICE)

torch.backends.cudnn.benchmark = True

# =====================================================
# Dataset 
# =====================================================

class ImageFolderDataset(Dataset):
    def __init__(self, folder, label):
        self.paths = [
            os.path.join(folder, f)
            for f in sorted(os.listdir(folder))
            if f.endswith(".png")
        ]
        self.label = label
        self.transform = transforms.ToTensor()

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        img = Image.open(self.paths[idx]).convert("RGB")
        return self.transform(img), self.label

# =====================================================
# CNN Model 
# =====================================================

class CNN(nn.Module):
    def __init__(self, n_classes, input_shape):
        super().__init__()

        c1, c2, c3 = 32, 64, 128

        self.features = nn.Sequential(
            nn.Conv2d(3, c1, 5, padding=2), nn.ReLU(),
            nn.Conv2d(c1, c1, 5, padding=2), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout(0.25),

            nn.Conv2d(c1, c2, 3, padding=1), nn.ReLU(),
            nn.Conv2d(c2, c2, 3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout(0.25),

            nn.Conv2d(c2, c3, 5, padding=2), nn.ReLU(),
            nn.Conv2d(c3, c3, 5, padding=2), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout(0.25),
        )

        with torch.no_grad():
            dummy = torch.zeros(1, *input_shape)
            flat_dim = self.features(dummy).view(1, -1).shape[1]

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(flat_dim, 128),
            nn.ReLU(),
            nn.Dropout(FINAL_DROPOUT),
            nn.Linear(128, n_classes)
        )

    def forward(self, x):
        return self.classifier(self.features(x))

# =====================================================
# Train function 
# =====================================================

def train_model(dataset, name):
    labels = torch.tensor([dataset[i][1] for i in range(len(dataset))])

    idx = list(range(len(dataset)))

    train_idx, test_idx = train_test_split(
        idx, test_size=0.20, stratify=labels, random_state=42
    )

    train_idx, val_idx = train_test_split(
        train_idx,
        test_size=0.125,
        stratify=labels[train_idx],
        random_state=42
    )

    train_ds = Subset(dataset, train_idx)
    val_ds   = Subset(dataset, val_idx)
    test_ds  = Subset(dataset, test_idx)

    train_loader = DataLoader(
        train_ds,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=4,
        pin_memory=True
    )

    val_loader = DataLoader(
        val_ds,
        batch_size=BATCH_SIZE,
        num_workers=4,
        pin_memory=True
    )

    sample_x, _ = dataset[0]
    model = CNN(2, sample_x.shape).to(DEVICE)

    optimizer = optim.RMSprop(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.CrossEntropyLoss()
    scaler = torch.cuda.amp.GradScaler()

    train_loss, val_loss, train_acc, val_acc = [], [], [], []

    for epoch in range(EPOCHS):

        # ---------------- TRAIN ----------------
        model.train()
        correct = total = running_loss = 0

        for xb, yb in train_loader:
            xb = xb.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer.zero_grad()

            with torch.cuda.amp.autocast():
                out = model(xb)
                loss = criterion(out, yb)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item() * yb.size(0)
            correct += (out.argmax(1) == yb).sum().item()
            total += yb.size(0)

        train_loss.append(running_loss / total)
        train_acc.append(correct / total)

        # ---------------- VALIDATION ----------------
        model.eval()
        correct = total = running_loss = 0

        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(DEVICE, non_blocking=True)
                yb = yb.to(DEVICE, non_blocking=True)

                with torch.cuda.amp.autocast():
                    out = model(xb)
                    loss = criterion(out, yb)

                running_loss += loss.item() * yb.size(0)
                correct += (out.argmax(1) == yb).sum().item()
                total += yb.size(0)

        val_loss.append(running_loss / total)
        val_acc.append(correct / total)

        print(f"{name} | Epoch {epoch+1}/{EPOCHS}")

    # ---------------- SAVE CURVES ----------------
    plt.figure(figsize=(7, 5))

    plt.subplot(2, 1, 1)
    plt.plot(train_loss,'b', label="Training")
    plt.plot(val_loss, 'r',label="Validation")
    plt.ylabel("Loss")
    plt.legend()

    plt.subplot(2, 1, 2)
    plt.plot(train_acc, 'b', label="Training")
    plt.plot(val_acc, 'r',label="Validation")
    plt.ylabel("Accuracy")
    plt.xlabel("Epochs")
    plt.ylim(0.5, 1)
    plt.legend()

    plt.tight_layout()
    plt.savefig(f"scenario_{name}_training_curves.png", dpi=500)
    plt.close()

    torch.save(model.state_dict(), f"scenario_{name}_model2.pt")

    return model, test_ds

# =====================================================
# Test evaluation 
# =====================================================

def evaluate(model, test_ds, name):
    loader = DataLoader(
        test_ds,
        batch_size=32,
        num_workers=4,
        pin_memory=True
    )

    preds, targets = [], []

    model.eval()
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            out = model(xb).argmax(1).cpu()
            preds.append(out)
            targets.append(yb)

    preds = torch.cat(preds)
    targets = torch.cat(targets)

    acc = (preds == targets).float().mean().item()
    print(f"TEST accuracy [{name}]: {acc:.4f}")

    cm = confusion_matrix(targets, preds)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="g", cmap="rocket", cbar=False)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(f"scenario_{name}_confusion2.png", dpi=500)
    plt.close()

    return acc

# =====================================================
# Load datasets
# =====================================================

infra_ds = ConcatDataset([
    ImageFolderDataset("./infrasound_rumbles", 0),
    ImageFolderDataset("./infrasound_noise", 1),
])

seis_ds = ConcatDataset([
    ImageFolderDataset("./seismic_rumbles", 0),
    ImageFolderDataset("./seismic_noise", 1),
])

comb_ds = ConcatDataset([infra_ds, seis_ds])

# =====================================================
# Train models
# =====================================================

infra_model, infra_test = train_model(infra_ds, "infrasound")
seis_model,  seis_test  = train_model(seis_ds,  "seismic")
comb_model,  _          = train_model(comb_ds,  "combined")

# =====================================================
# Cross-domain evaluation
# =====================================================

test_accuracies = {
    "Infra → Infra": evaluate(infra_model, infra_test, "infra_on_infra"),
    "Infra → Seismic": evaluate(infra_model, seis_test, "infra_on_seismic"),
    "Seismic → Seismic": evaluate(seis_model, seis_test, "seismic_on_seismic"),
    "Seismic → Infra": evaluate(seis_model, infra_test, "seismic_on_infra"),
    "Combined → Infra": evaluate(comb_model, infra_test, "combined_on_infra"),
    "Combined → Seismic": evaluate(comb_model, seis_test, "combined_on_seismic"),
}

print("\n" + "=" * 55)
print("FINAL TEST ACCURACY SUMMARY")
print("=" * 55)
for k, v in test_accuracies.items():
    print(f"{k:<25}: {v:.4f}")
print("=" * 55)
